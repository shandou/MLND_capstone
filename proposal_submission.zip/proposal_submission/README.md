# Click Fraud Detector
**MLND capstone project**<br>
Shan Dou<br>
June 30, 2018<br>


## Access to data files
The raw data files are too large for direct submission (12GB). The dataset is downloadable on Kaggle webiste: https://www.kaggle.com/c/talkingdata-adtracking-fraud-detection